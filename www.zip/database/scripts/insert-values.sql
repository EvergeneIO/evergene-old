INSERT INTO `endpoints` (`name`, `status`) VALUES
	('hug', 1),
	('tickle', 0),
	('slap', 1),
	('poke', 0),
	('pat', 1),
	('kiss', 1),
	('feed', 0),
	('cuddle', 1),
	('awwnime', 0),
	('memes', 1),
	('dankmemes', 1),
	('animemes', 0),
	('animegif', 1),
	('animewp', 1),
	('moe', 0),
	('puppy', 1),
	('aww', 1),
	('floof', 1),
	('partner', 1),
	('new', 1),
	('update', 1),
	('delete', 1);

	INSERT INTO `perms` (`name`, `bit`) VALUES
	('sfw', 1),
	('nsfw', 2),
	('partner', 4),
	('admin', 8);