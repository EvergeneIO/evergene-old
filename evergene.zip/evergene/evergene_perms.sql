create table perms
(
    name varchar(50) null,
    bit  int         null
);

INSERT INTO evergene.perms (name, bit) VALUES ('sfw', 1);
INSERT INTO evergene.perms (name, bit) VALUES ('nsfw', 2);
INSERT INTO evergene.perms (name, bit) VALUES ('partner', 4);
INSERT INTO evergene.perms (name, bit) VALUES ('admin', 8);
INSERT INTO evergene.perms (name, bit) VALUES ('private', 16);