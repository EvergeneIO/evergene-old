create table partner
(
    serverId bigint null,
    total    int    null,
    online   int    null
);

INSERT INTO evergene.partner (serverId, total, online) VALUES (710781300100956170, null, null);