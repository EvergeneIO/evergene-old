create table endpoints
(
    name   varchar(50) null,
    status int         null,
    ping   int         null
);

INSERT INTO evergene.endpoints (name, status, ping) VALUES ('hug', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('tickle', 0, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('slap', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('poke', 0, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('pat', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('kiss', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('feed', 0, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('cuddle', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('awwnime', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('memes', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('dankmemes', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('animemes', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('animegif', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('animewp', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('moe', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('puppy', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('aww', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('floof', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('partner', 1, null);
INSERT INTO evergene.endpoints (name, status, ping) VALUES ('endpoint', 1, null);