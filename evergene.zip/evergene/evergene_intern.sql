create table intern
(
    name   varchar(50) null,
    status int         null,
    msg    varchar(50) null
);

